<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Connect to database using PDO
require_once 'db.php';

// Create table if it doesn't exist
$createTable = "
CREATE TABLE IF NOT EXISTS reviews (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100),
    album_name VARCHAR(100),
    review TEXT,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

try {
    $pdo->exec($createTable);
} catch (PDOException $e) {
    exit("Error creating table: " . $e->getMessage());
}

// Get form data
$username = $_SESSION['username'];
$albumName = $_POST['albumName'] ?? '';
$review = $_POST['review'] ?? '';
$rating = $_POST['star'] ?? 0;

// Validate inputs
if (empty($albumName) || empty($review) || empty($rating)) {
    exit("Error: all fields are required.");
}

// Insert review using prepared statement (prevents SQL injection)
$q = "INSERT INTO reviews (username, album_name, review, rating)
      VALUES (:username, :albumName, :review, :rating)";

try {
    $stmt = $pdo->prepare($q);
    $stmt->execute([
        ':username' => $username,
        ':albumName' => $albumName,
        ':review' => $review,
        ':rating' => $rating
    ]);
    header("Location: Profilepage.php");
    exit();
} catch (PDOException $e) {
    echo "Error inserting review: " . $e->getMessage();
}
?>